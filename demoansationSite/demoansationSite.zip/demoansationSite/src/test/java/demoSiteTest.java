import org.junit.Before;
import org.openqa.selenium.WebDriver;

public class demoSiteTest
{
    WebDriver driver
    @Before
    public  void setUp()
    {
        System.setProperty("System");

    }
}
